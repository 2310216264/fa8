<?php



include("../config/conn.php");

include("../config/function.php");

include("../config/xy.php");

$sj=date("Y-m-d H:i:s");

if(returnsx("p")!=-1){$page=returnsx("p");}else{$page=1;}

$px="order by id desc";



?>

<html>

<head>

<meta http-equiv="x-ua-compatible" content="ie=7" />

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<title>�������� - <?=webname?></title>

<? include("../tem/cssjs.html");?>

<link rel="stylesheet" href="./css/index.css">

<!--<link rel="stylesheet" href="./css/tool.css">-->

</head>



<body>

<? include("../tem/top.html");?>

<? include("../tem/top1.html");?>







<div id="banner_tool">

  <h1>ǰ�˹��߿�</h1>

  <h2>�򵥡�ֱ�ۡ�ǿ����ǰ�˹��ֿ߲⣬��Webǰ�˿�����Ѹ�١�</h2>

</div>

<div class="yjcode"  style="width:1260px;">

	<!--ǰ�˱ر�����-->

    <div class="tool_box" style="width:1260px;max-width:1260px;">

    	<div class="cn_nav"> <span class="title">ǰ�˱ر�����</span> </div>

    	

    	<ul class="iconlist">

    	<?

            $ses=" where id<>1000";

            // $page=$_GET["page"];if($page==""){$page=1;}else{$page=intval($_GET["page"]);}

            pagef($ses,24,"yjcode_tool",$px);while($row=mysql_fetch_array($res)){

         

        ?>	

        <li>

            <img class="icon" src="/tool/upload/<?=$row['tool_img']?>">

            <div class="info cl">

                <h3><?=$row['tool_name']?></h3>

                <p><?=$row['tool_title']?></p>

                <span>��ȡ�룺<?=$row['tool_tqm']?></span>

                <a href="<?=$row['tool_link']?>" class="btn btn-primary" target="_blank">����</a> 

            </div> 

        </li>

    	<? }?>

        </ul>

	</div>



		

	<div class="npa">

	<?

	$nowurl="search";

	$nowwd="";

	require("../tem/page.html");

	?>

	</div>

</div>



<? include("../tem/bottom.html");?>

</body>

</html>