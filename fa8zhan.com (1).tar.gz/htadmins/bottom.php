<div class="bottomfd"></div>
<div class="bfbbottom">
 <div class="d1">尊敬的管理员，您正在使用<?=webname?>管理后台，当长时间不操作，建议您【<a href="un.php" class="green">退出登录</a>】，以保证安全。</div>
 <div class="d2"><a href="../" target="_blank" class="a1">返回首页</a></div>
</div>
