 <div class="bqu1">
 <a href="userlist.php">会员列表</a>
 <a href="user.php?id=<?=$id?>" id="rtit1">基本资料</a>
 <a href="shop.php?id=<?=$id?>" id="rtit2">店铺资料</a>
 <a href="usermoney.php?id=<?=$id?>" id="rtit3">金钱管理</a>
 <a href="userbao.php?id=<?=$id?>" id="rtit6">保证金</a>
 <a href="userjf.php?id=<?=$id?>" id="rtit4">积分管理</a>
 <a href="userrz.php?id=<?=$id?>" id="rtit5">实名认证</a>
 <a href="zzrz.php?id=<?=$id?>" id="rtit7">执照认证</a>
 </div> 
