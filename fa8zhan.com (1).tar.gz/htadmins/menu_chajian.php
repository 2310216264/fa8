<div class="treebox">
 <ul class="menu">

 <li class="level1" id="leftmenu1" onclick="leftonc(1)">
  <a href="javascript:void(0);" class="a1"><em></em>插件管理<i></i></a>
  <ul class="level2">
  <li><a href="chajian.php">已购买插件</a></li>
  <li><a href="http://www.yj99.cn" target="_blank">选购新插件</a></li>
  </ul>
 </li>

 </ul>
</div>
<!--LEFT E-->
<script language="javascript">
leftonc(<?=$leftid?>);
</script>







