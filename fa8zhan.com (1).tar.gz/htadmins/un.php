<?php
require("../config/conn.php");
require("../config/function.php");
$_SESSION["SHOPADMIN"]="";
$_SESSION["SHOPADMINPWD"]="";
php_toheader("index.php");
?>
