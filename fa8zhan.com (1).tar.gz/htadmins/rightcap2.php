 <div class="bqu1">
 <a href="adtypeglobal.php" id="rtit0">首页通用广告</a>
 <a href="adtype.php" id="rtit1">模板首页广告</a>
 <a href="adtype2.php" id="rtit2">商品页广告</a>
 <a href="adtype3.php" id="rtit3">资讯广告</a>
 <a href="adtype4.php" id="rtit4">其他广告</a>
 <a href="adtype5.php" id="rtit5">手机版通用广告</a>
 <a href="adtype6.php" id="rtit6">手机模板广告</a>
 </div> 
