<?
include("../../../../config/conn.php");
include("../../../../config/function.php");
?>
<div class="bfb bfbtop1">
<div class="yjcode">
 <div class="top1">
  <h1 class="logo"><a href="<?=weburl?>"><img alt="<?=webname?>" border="0" src="<?=weburl?>img/logo.png?t=<?=time()?>" /></a></h1>
  
  <form name="topf1" method="post" onSubmit="return topftj()">
  <ul class="u1">
  <li class="l1" onMouseOver="topover()" onMouseOut="topout()">
  <span id="topnwd">��Ʒ</span>
  <div id="topdiv" style="display:none;">
  <a href="javascript:void();" onClick="topjconc(1,'��Ʒ')">��Ʒ</a>
  <a href="javascript:void();" onClick="topjconc(2,'����')">����</a>
  <a href="javascript:void();" onClick="topjconc(3,'��Ѷ')">��Ѷ</a>
  </div>
  </li>
  <li class="l2"><input name="topt" id="topt" type="text" /></li>
  <li class="l3"><input type="image" src="<?=weburl?>homeimg/aiyouImg/btn1.gif" /></li>
  </ul>
  </form>
  
  <? if($rowcontrol[ifopenshop]=="on"){?>
  <div class="sqkd"><a href="<?=weburl?>user/openshop1.php">���뿪��</a></div>
  <? }else{?>
  <div class="sqkd"><a href="<?=weburl?>user/">��Ա����</a></div>
  <? }?>
 
  <div class="menu fontyh">
   <!--��B-->
   <? $ai=returncount("yjcode_type where admin=1");?>
   <span id="typeallnum" style="display:none;"><?=$ai?></span>
   <div class="m1" onmouseover="leftmenuover()" onmouseout="leftmenuout()">
   <span class="t">ȫ������</span>
   <!--������������ʼ-->
   <div class="menun fontyh" id="leftmenu" style="display:none;">
    <!--��ƷB-->
    <? 
	$sqlad="select * from yjcode_ad where zt=0 and adbh='aiyou_01' order by xh asc";mysql_query("SET NAMES 'GBK'");$resad=mysql_query($sqlad);
	$i=1;while1("*","yjcode_type where admin=1 order by xh asc");while($row1=mysql_fetch_array($res1)){
	$rowad=mysql_fetch_array($resad);
	?>
    <div class="menu1" id="yhmenu<?=$i?>" onmouseover="yhmenuover(<?=$i?>)" onmouseout="yhmenuout(<?=$i?>)">
     <div class="lu1"><a href="<?=weburl?>product/search_j<?=$row1[id]?>v.html"><span class="s0"><img src="<?=weburl?><?=returnjgdw($rowcontrol[addir],"","gg")?>/<?=$rowad[bh].".".$rowad[jpggif]?>" /></span><span class="s1"><?=$row1[type1]?></span></a></div>
     <div class="rmenu rmenu1" style="display:none;margin-top:-<?=50*$i?>px;min-height:<?=50*returncount("yjcode_type where admin=1")?>px;" id="rmenu<?=$i?>">
      
	  <? while2("*","yjcode_type where type1='".$row1[type1]."' and admin=2 order by xh asc");while($row2=mysql_fetch_array($res2)){?>
	  <span class="s1"><a href="<?=weburl?>product/search_j<?=$row1[id]?>v_k<?=$row2[id]?>v.html"><?=$row2[type2]?></a></span>
	  <? }?>
      
	  <? while2("*","yjcode_type where type1='".$row1[type1]."' and admin=2 order by xh asc");while($row2=mysql_fetch_array($res2)){?>
      <ul class="ru1" style="display:none;">
      <li class="l1"><a href="<?=weburl?>product/search_j<?=$row1[id]?>v_k<?=$row2[id]?>v.html"><?=$row2[type2]?></a></li>
      <li class="l2">
      <? while3("*","yjcode_type where type1='".$row1[type1]."' and type2='".$row2[type2]."' and admin=3 order by xh asc");while($row3=mysql_fetch_array($res3)){?>
      |&nbsp;&nbsp;&nbsp;<a href="<?=weburl?>product/search_j<?=$row1[id]?>v_k<?=$row2[id]?>v_m<?=$row3[id]?>v.html"><?=$row3[type3]?></a>&nbsp;&nbsp;&nbsp;
      <? }?>&nbsp;
      </li>
      </ul>
	  <? }?>
      
      <? 
	  $si=0;
	  $sbarr=array();
	  while2("*","yjcode_typesx where admin=1 and typeid=".$row1[id]." and ifsel=1 order by xh asc");while($row2=mysql_fetch_array($res2)){
	  $ev="e".$row2[id]."_";
	  $sbarr[$si]=$ev;
	  ?>
	  <ul class="ru1" style="display:none;">
	  <li class="l1"><?=$row2[name1]?></li>
	  <li class="l2">
	  <? while3("*","yjcode_typesx where admin=2 and name1='".$row2[name1]."' and typeid=".$row2[typeid]." order by xh asc");while($row3=mysql_fetch_array($res3)){?>
	  |&nbsp;&nbsp;&nbsp;<a href="<?=weburl?>product/search_j<?=$row1[id]?>v_<?=$ev.$row3[id]?>v.html"><?=$row3[name2]?></a>&nbsp;&nbsp;&nbsp;
	  <? }?>&nbsp;
	  </li>
	  </ul>
	  <? $si++;}?>


     </div>
    </div>
    <? $i++;}?>
    <!--��ƷE-->
   </div>
   <!--��������������-->
   </div> 
   <!--��E-->

   <div class="m2">
   <a href="<?=weburl?>" id="topmenu1">��ҳ</a>
   <? while1("*","yjcode_ad where adbh='ADI02' and type1='����' order by xh asc");while($row1=mysql_fetch_array($res1)){?>
   <a href="<?=$row1[aurl]?>"><?=$row1[tit]?></a>
   <? }?>
   </div>
  </div>
 
 </div>
</div>
</div>
