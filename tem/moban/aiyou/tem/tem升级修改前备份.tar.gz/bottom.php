<?
include("../../../../config/conn.php");
include("../../../../config/function.php");
?>
<div class="bfb bfbbottom">
<div class="yjcode">

 <div class="d1">
 <ul class="u1">
 <? while1("*","yjcode_helptype where admin=1 order by xh asc limit 5");while($row1=mysql_fetch_array($res1)){?>
 <li>
 <span><a href="<?=weburl?>help/search_j<?=$row1[id]?>v.html" target="_blank"><?=$row1[name1]?></a></span>
 <? 
 while2("*","yjcode_helptype where admin=2 and name1='".$row1[name1]."' order by xh asc limit 5");while($row2=mysql_fetch_array($res2)){
 $aurl="search_j".$row1[id]."v_k".$row2[id]."v.html";
 if(returncount("yjcode_help where ty1id=".$row1[id]." and ty2id=".$row2[id])==1){
 while3("id,ty1id,ty2id","yjcode_help where ty1id=".$row1[id]." and ty2id=".$row2[id]);$row3=mysql_fetch_array($res3);
 $aurl="view".$row3[id].".html";
 }
 ?>
 <a href="<?=weburl?>help/<?=$aurl?>" target="_blank" class="a1"><?=$row2[name2]?></a><br>
 <? }?>
 </li>
 <? }?>
 </ul>
 </div>
 
 <div class="d2">
 <strong>��ϵ����</strong><br>
 <? while1("*","yjcode_ad where adbh='aiyou_03' and zt=0 order by xh asc");if($row1=mysql_fetch_array($res1)){echo $row1[txt];}?>
 </div>
 
 <div class="d3">
 <? while1("*","yjcode_ad where adbh='aiyou_04' and zt=0 order by xh asc");if($row1=mysql_fetch_array($res1)){?>
 <a href="<?=$row1[aurl]?>" target="_blank"><img src="<?=weburl?><?=returnjgdw($rowcontrol[addir],"","gg")?>/<?=$row1[bh].".".$row1[jpggif]?>" width="100" height="100" /><br><?=$row1[tit]?></a>
 <? }?>
 </div>
 
 <ul class="u2">
 <li class="l1">
 <a href="<?=weburl?>help/aboutview2.html" target="_blank">��������</a>&nbsp;&nbsp;
 <a href="<?=weburl?>help/aboutview3.html" target="_blank">������</a>&nbsp;&nbsp;
 <a href="<?=weburl?>help/aboutview4.html" target="_blank">��ϵ����</a>&nbsp;&nbsp;
 <a href="<?=weburl?>help/aboutview5.html" target="_blank">��˽����</a>&nbsp;&nbsp;
 <a href="<?=weburl?>help/aboutview6.html" target="_blank">��������</a>&nbsp;&nbsp;
 <a href="<?=weburl?>help/map.html" target="_blank">��վ��ͼ</a>
 <br>
 <a href="http://www.beian.miit.gov.cn/" target="_blank"><?=$rowcontrol[beian]?></a> <?=$rowcontrol[webtj]?><i>&nbsp;&nbsp;|&nbsp;&nbsp;Copyright <?=date("Y")+1?> <?=webname?>  ��Ȩ����</i>
 </li>
 <li class="l2">
 <? while1("*","yjcode_ad where adbh='aiyou_05' and zt=0 order by xh asc limit 5");while($row1=mysql_fetch_array($res1)){?>
 <a href="<?=$row1[aurl]?>" target="_blank"><img src="<?=weburl?><?=returnjgdw($rowcontrol[addir],"","gg")?>/<?=$row1[bh].".".$row1[jpggif]?>" width="106" height="40" /></a>
 <? }?>
 </li>
 </ul>
 
 <? adwhile("ADI01");?>
 
</div>
</div>

<? while1("*","yjcode_ad where adbh='ADKF' and zt=0 order by xh asc limit 1");if($row1=mysql_fetch_array($res1)){echo $row1[txt];}?>






<!-- �Ҳม����ʼ -->
<div class="right-btn-group"> 
<ul class="btn-group"> 
    <li>
        <a href="<?=weburl?>user/" class="icon-2 login-a">
        <span>��������</span>
        </a>
    </li> 
    <li class="sign-but">
        <a href="<?=weburl?>user/qiandao.php" class="icon-4 login-a" rel="nofollow">
        <span>���ǩ��</span>
        </a>
    </li> 
    <li>
        <a href="<?=weburl?>user/newslx.php" class="icon-3 login-a">
        <span>��ҪͶ��</span>
        </a>
    </li> 
    <li>
        <a href="<?=weburl?>user/gdlx.php" class="icon-5">
        <span>�������</span>
        </a>
    </li> 
</ul> 
<div class="show-wechat"> 
    <a href="<?=weburl?>mt" class="icon-7">
    <span>
    <img src="<?=weburl?>tem/getqr.php?u=<?=weburl?>m&size=4" width="137" height="137" alt="�ֻ���ά��">
    <em>�����ֻ���</em>
    </span>
    </a>
</div> 
<div class="to-top">
    <a href="javascript:;" onclick="gotoTop();return false;" class="icon-6" rel="nofollow"><span>���ض���</span></a>
</div>
</div>
<!-- �Ҳม������ -->


