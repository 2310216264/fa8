<?
include("../../../../config/conn.php");
include("../../../../config/function.php");
$wxlogin=preg_split("/,/",$rowcontrol[wxlogin]);
?>


<? 
while1("*","yjcode_ad where adbh='ADTOP' and zt=0 order by xh asc");while($row1=mysql_fetch_array($res1)){
$tp="../".returnjgdw($rowcontrol[addir],"","gg")."/".$row1[bh].".".$row1[jpggif];
$image_size= getimagesize("../../../".$tp);
?>
<div class="topbanner_hj" style="background:url(<?=$tp?>) no-repeat center 0;height:<?=$image_size[1]?>px;"><a href="<?=$row1[aurl]?>" target="_blank"></a></div>
<? }?>

 <!-- top -->
 <div class="header-sm">
        <div class="header-sm-container">
            <div class="header-nav">
            	<div class="ytfm hover-box nav-fixed"><a href="<?=weburl?>">��ҳ</a></div>
                <!-- ��Ʒ���� -->
                
                <div class="ytfm hover-box nav-fixed">
                    <a href="<?=weburl?>product/" class="arrow">��Ʒ����</a>
                    <div class="nav-list hover-box green ">
                        <a href="<?=weburl?>product/search_j1v.html"><i class="icon icon-embed2"></i><span>��վԴ��</span></a>
                        <a href="<?=weburl?>product/search_j7v.html"><i class="icon icon-fire"></i><span>����ز�</span></a>
                    </div>
                </div>
                <!-- ��Ʒ���� -->
                <!-- �̼����� -->
                <div class="ytfm hover-box nav-fixed"><a href="<?=weburl?>shop/">�̼�����</a></div>
                <div class="ytfm hover-box nav-fixed"><a href="<?=weburl?>news/">�����̳�</a></div>
                <!-- �̼����� -->
                <!-- ������Ѷ -->
                <!-- <div class="ytfm hover-box ">
                    <a href="<?=weburl?>news/" class="arrow">������Ѷ</a>
                    <div class="nav-list blue">
                        <a href="<?=weburl?>news/newslist_j21v.html"><i class="icon icon-display"></i><span>ϵͳ����</span></a>
                        <a href="<?=weburl?>news/newslist_j67v.html"><i class="icon icon-p-sjyuansu"></i><span>��ҳǰ��</span></a>
                    </div>
                </div> -->
                <!-- ������Ѷ -->
                <!-- ���� -->
                <div class="ytfm hover-box nav-fixed">
                    <a href="javascript:;" class="arrow"><span class="dot">
                    ...
                    </span></a>
                    <div class="nav-list">
                        <!-- <a href="<?=weburl?>vipfuli"  target="_blank"><i class="icon icon-p-activity"></i><span>����</span></a> -->
                        <a href="<?=weburl?>product/" ><i class="icon icon-p-new"></i><span>ÿ������</span></a>
                        <a href="<?=weburl?>task/"   ><i class="icon icon-p-QQ"></i><span>�������</span></a>
                        <!-- <a href="<?=weburl?>vipfuli"  target="_blank"><i class="icon icon-p-tool"></i><span>��ѹ���</span></a> -->
                        <a href="<?=weburl?>mt/"    ><i class="icon icon-p-prototype"></i><span>�ֻ���</span></a>
                    </div>
                </div>
                <!-- ���� -->

            </div>
            <!-- �� -->
            <div class="container-sm">
                <!-- logo -->
                <div class="logo-sm fl">
                    <!-- logo -->
                    <a href="<?=weburl?>">
                        <img src="<?=weburl?>img/logo.png" width="244" height="52" alt="logo">
                    &nbsp;</a>
                </div>
                <!-- ��¼ע�� -->
                <!-- δ��¼ -->
                
                <div class="header-user login fr" id="notlogin">
                    <p class="sm-hy"><a href="/user/">��¼</a></p>
                    <p class="sm-hy btn-green-linear"><a href="/reg/reg.php">ע��</a></p>
                </div>

                <!-- �������� -->
                <!-- �Ѿ���¼ -->
                <div class="header-user info header-right fr" id="yeslogin" style="display: none;">
                    <div class="user-img"><a href="<?=weburl?>user/"><img src="<?=weburl?>img/user-default.png" id="topuimg" width="40" height="40" alt="ico"></a></div>
                    <div class="user-info js-copy-id">
                        <p><span id="yesuid" class="s1">��ע���û�</span></p>
                        <p class="clearfix"></p>
                    </div>
                    <div class="header-drop">
                        <!-- ��֤ -->
                        <div class="user-header">
                            <span class="int-img v0"></span>
                            <a href="<?=weburl?>user/" target="_blank" class="user-name" id="yesuid"></a>
                            <div id="topurz">
                                <span class="icon-box warning"><em class="icon icon-p-phone"></em><i class="icon icon-p-x"></i>
                                    <a href="<?=weburl?>user/mobbd.php" title="�ֻ���֤"></a>
                                </span>
                                <span class="icon-box warning"><em class="icon icon-p-Bind"></em><i class="icon icon-p-x"></i>
                                    <a href="<?=weburl?>user/qq.php" title="QQ��֤"></a>
                                </span>
                                <span class="icon-box warning"><em class="icon icon-envelop"></em><i class="icon icon-p-x"></i>
                                    <a href="<?=weburl?>user/inf.php" title="������֤"></a>
                                </span>
                            </div>
                        </div>
                        <div class="user-int">
                            <span class="fl"><a href="<?=weburl?>user/userdj.php" id="topudj">��ͨ(����:���ò�����)</a></span>
                            <a href="<?=weburl?>user/paylog.php" target="_blank" class="fr int-count">���&nbsp;:&nbsp;<span id="topmoney">0.1</span></a>
                            <a href="<?=weburl?>user/jflog.php" target="_blank" class="fr int-count">����&nbsp;:&nbsp;<span id="topjf">10</span></a>
                        </div>
                        <!-- ��Ա���� -->
                        <!-- <div class="user-vip">
                            <span class="fl vip-type"><i class="icon-img vip11"></i>��ͨ</span>
                            <span class="fl vip-count">0Ԫ/��</span>
                            <a href="<?=weburl?>user/userdj.php" class="fl vip-text">��Ա��Ʒ��10��</a><a href="<?=weburl?>user/userdj.php" class="fr" id="tdjxh1">�ѿ�ͨ</a>
                        </div>
                        <div class="user-vip">
                            <span class="fl vip-type"><i class="icon-img vip21"></i>�׽�</span>
                            <span class="fl vip-count">100Ԫ/��</span>
                            <a href="<?=weburl?>user/userdj.php" class="fl vip-text">��Ա��Ʒ��9.7��</a><a href="<?=weburl?>user/userdj.php" class="fr" id="tdjxh2">��ͨVIP ?</a>
                        </div>
                        <div class="user-vip">
                            <span class="fl vip-type"><i class="icon-img vip31"></i>�ƽ�</span>
                            <span class="fl vip-count">200Ԫ/��</span>
                            <a href="<?=weburl?>user/userdj.php" class="fl vip-text">��Ա��Ʒ��9.5��</a><a href="<?=weburl?>user/userdj.php" class="fr" id="tdjxh3">��ͨVIP ?</a>
                        </div>
                        <div class="user-vip">
                            <span class="fl vip-type"><i class="icon-img vip41"></i>��ʯ</span>
                            <span class="fl vip-count">500Ԫ/��</span>
                            <a href="<?=weburl?>user/userdj.php" class="fl vip-text">��Ա��Ʒ��9��</a><a href="<?=weburl?>user/userdj.php" class="fr" id="tdjxh4">��ͨVIP ?</a>
                        </div> -->
                        <!-- ��Ա���� -->

                        <!-- �������Ŀ������ -->
                        <div class="user-nav">
                            <a href="/user/" class="fl" title="��������" target="_blank"><i class="icon icon-rengezhongxin"></i>��������</a>
                            <a href="/user/order.php" class="fl" title="�ҵĶ���" target="_blank" rel="nofollow"><i class="icon icon-shourumingxi"></i>�ҵĶ���</a>
                            <a href="/user/pay.php" class="fl" title="�û���ֵ" target="_blank" rel="nofollow"><i class="icon icon-credit-card"></i>�û���ֵ</a>
                            <a href="/help/" class="fl" title="���ְ���" target="_blank"><i class="icon icon-shoucang"></i>���ְ���</a>
                        </div>

                        <div class="user-footer">
                            <a href="/user/" target="_blank" class="fl">�ʺ�����</a>
                            <a href="" class="fr" target="_blank" rel="nofollow">�˳�</a>
                        </div>
                    </div>

                </div>
                <!-- �������� -->

                <!-- ���ﳵ -->
                <div class="messageSystem" id="messageSystem" style="display: none;">
                    <ul class="messageSystem-model" onmouseover="topgetc();"><span
                            class="messageSystem-icon icon icon-cart"></span><span
                            class="messageSystem-txt">���ﳵ</span><span class="messageSystem-base-info">
                            <li class="messageSystem-num">
                                <p id="topcarnum">0</p>
                            </li>
                        </span></ul><span class="message-base-info">
                        <div class="messageSystem-after" id="topcar">
                            <li class="messageSystem-link">
                                <a class="messageSystem-btn" href="javascript:void(0);" onclick="topdelcar()"
                                    data-info="1">��չ��ﳵ</a>
                                <a class="messageSystem-btn2" href=""
                                    target="_blank">���Ż�<span>0.00</span>Ԫ��ʵ������<span class="s1">0.00</span></a>
                                <a class="jiesuan" href="">�鿴���ﳵ</a>
                            </li>
                        </div>
                    </span>
                    <input type="hidden" id="isSendAjaxInfo" value="1">
                </div>
                <!-- ���ﳵ -->
                <div class="header-upload hover-box header-right fr"><i class="icon icon-p-shangchuan"></i><a href="" target="_blank">����</a></div>
            </div>
        </div>
    </div>


<span id="webhttp" style="display:none"><?=weburl?></span>

<!-- <script language="javascript">
userCheckses();
</script> -->
