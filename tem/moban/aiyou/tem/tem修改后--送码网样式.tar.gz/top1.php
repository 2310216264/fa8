<?
include("../../../../config/conn.php");
include("../../../../config/function.php");
?>

<!-- �������� -->
    <div class="index-sm">
        <div class="container-sm">
            <div class="ssfl">
                <div class="ssflz">



                    <!-- <form name="topf1" method="post" onsubmit="return topftj()">
                        <ul class="u1">
                        <li class="l1" onmouseover="topover()" onmouseout="topout()">
                        <span id="topnwd">��Ʒ</span>
                        <div id="topdiv" style="display:none;">
                        <a href="javascript:void();" onclick="topjconc(1,'��Ʒ')">��Ʒ</a>
                        <a href="javascript:void();" onclick="topjconc(2,'����')">����</a>
                        <a href="javascript:void();" onclick="topjconc(3,'��Ѷ')">��Ѷ</a>
                        </div>
                        </li>
                        <li class="l2"><input name="topt" id="topt" type="text"></li>
                        <li class="l3"><input type="image" src="https://www.a8zhan.com/homeimg/aiyouImg/btn1.gif"></li>
                        </ul>
                    </form> -->




                    <div class="fenlei1"  ><i class="icont-close"></i><b id="w_show">��Ʒ</b></div>
                    <div class="fl search-input">
                        <div>
                            <input type="text" id="search-text"  class="fl"
                                name="topt" autocomplete="off" disableautocomplete="" placeholder="������Ҫ����������" value=""
                                data-isshow="1" data-where="1">
                            </div>
                        <input type="hidden" id="w_search" value="1">
                    </div>
                    <div class="sm-hy btn-green-linear btn-search fr" id="search_btn"><i class="icon icon-p-search"></i>
                    </div>
                    <div class="search-type" id="topdiv" style="display: none;">
                        <dl class="list-box">
                            <dd data-id="1" onclick="topjconc(1,'��Ʒ')">��Ʒ</dd>
                            <dd data-id="2" onclick="topjconc(2,'����')">����</dd>
                            <dd data-id="3" onclick="topjconc(3,'��Ѷ')">��Ѷ</dd>
                        </dl>
                    </div>
                </div>
            </div>

            <!-- �������� -->
            <div class="rmss"><span>�������� :</span>
                <a href="" target="_blank">WordPress</a>
                <a href="" target="_blank">֯��</a>
                <a href="" target="_blank">��ҵ����</a>
                <a href="" target="_blank">С˵Դ��</a>
                <a href="" target="_blank">Discuz</a>
            </div>
        </div>
    </div>
    <!-- top1 -->