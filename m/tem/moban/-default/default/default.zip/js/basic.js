//�ײ�����
function bottomjd(x){
document.getElementById("bottom"+x).className="dm dm1";
document.getElementById("bottom"+x+"img").src=document.getElementById("webhttp").innerHTML+"m/img/bottom"+x+"_1.png";
}
