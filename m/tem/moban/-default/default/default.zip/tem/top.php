<!--ͷ��B-->
<div class="mbtop1 box">
 <div class="d1" onClick="javascript:history.go(-1);"><img src="../img/back.png" /></div>
 <div class="d2"><?=$nowpagetit?></div>
 <div class="d3"><a href="../user/"><img src="../img/tx.png" /></a></div>
</div>
<!--ͷ��E-->
