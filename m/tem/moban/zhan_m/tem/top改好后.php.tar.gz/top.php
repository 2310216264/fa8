<? if(empty($nowpagebk)){$nowpagebk="window.history.back(-1);";}else{$nowpagebk="gourl('".$nowpagebk."')";}?>
<div style="display:none;" id="webhttp"><?=weburl?></div>
<div id="bodywrap" class="" style="display: block;">
    <div class="header" id="header" style="margin-left:0px;transition:0.5s;-moz-transition:0.5s;-webkit-transition:0.5s;-o-transition:0.5s;">
        <div class="box box2">
            <div class="userface" onclick="window.location='/m/user'" style="display: block;"><img src="/m/img/nonetx.gif" id="sjcl3"></div>
                <div class="scicon" onclick="topxiala()"></div>
                <div class="listicon" id="asideclick" style="display: block;"><div class="ybg" style="display: block;"></div></div>
            <div class="text" style="display: block;"><span>A8վ</span></div>
        </div>
    </div>
</div>
<div id="topzhezhao"></div>
<div id="asidebg" style="display: none;"></div>

<aside class="asidemenu" style="/* right:-17.5em; */transition:0.5s;-moz-transition:0.5s;-webkit-transition:0.5s;-o-transition:0.5s;">
    <div>
     <div class="asideuser" id="notlogin" onclick="window.location='<?=weburl?>m/user/touxiang.php';" style="display:none;">
         <div class="face"><img src="/m/img/nonetx.gif"></div>
         <div class="name"><div class="rbg iconfont"></div><span>���¼</span></div>
         <div class="message">��¼��鿴����</div>
     </div>
     <div class="asideuser" id="yeslogin" style="" onclick="window.location='<?=weburl?>m/user/';">
         <div class="face"><a href="<?=weburl?>m/user/touxiang.php"><img src="/m/img/nonetx.gif" id="sjcl2" width="40" height="40" alt="ico"></a></div>
         <div class="name"><div class="rbg iconfont"></div><span id="yesuid">zhou</span></div>
         <div class="message"><span id="sjcl1">0.10</span></div>
     </div>
 
    </div>
    <div class="gk-cart" onclick="window.location='<?=weburl?>m/user/car.php'"><div class="rbg iconfont"></div><div class="carticon"></div><span>���ﳵ</span></div>
    <div class="clear"></div>
    <ul style="height:517.7376px;">
        <li onclick="window.location='<?=weburl?>m/'"><div class="rbg iconfont"></div><div class="icon icon1"></div><div class="text">��ҳ</div></li>
        <li onclick="window.location='<?=weburl?>m/product/search.html'"><div class="rbg iconfont"></div><div class="icon icon2"></div><div class="text">��Ʒ</div></li>
        <li onclick="window.location='<?=weburl?>m/news/newslist.html'"><div class="rbg iconfont"></div><div class="icon icon4"></div><div class="text">����</div></li>
        <li onclick="window.location='<?=weburl?>m/task/'"><div class="rbg iconfont"></div><div class="icon icon5"></div><div class="text">����</div></li>
        <li onclick="window.location='<?=weburl?>m/user/pay.php'"><div class="rbg iconfont"></div><div class="icon icon6"></div><div class="text">��ֵ</div></li>
        <li onclick="window.location='<?=weburl?>m/user/order.php'"><div class="rbg iconfont"></div><div class="icon icon7"></div><div class="text">�ҵĶ���</div></li>
        <li onclick="window.location='<?=weburl?>m/user/shezhi.php'"><div class="rbg iconfont"></div><div class="icon icon9"></div><div class="text">�û�����</div></li>
        <li class="last" onclick="window.location='<?=weburl?>m/user/sell.php'"><div class="rbg iconfont"></div><div class="icon icon8"></div><div class="text">�̻�����</div></li>
    </ul>
</aside>
<script language="javascript">
userCheckses();
</script>
<div id="topxialam" style="display:none;">
    <div class="topxialam1 box">
        <div class="search_box">
            <div class="search">
                <form id="index_search_form" method="post" action="<?=weburl?>m/search/index.php?admin=1" target="_parent" onsubmit="return submit_search();">
                    <div class="text_box">
                        <input id="keyword" name="topt" type="text" placeholder="������ؼ���" class="keyword text" onkeydown="this.style.color='#404040'" autocomplete="off">
                    </div>
                    <input type="submit" value="" class="submit" dd_name="����">
                </form>
            </div>
        </div>
    </div>
    
    <div class="topxialam2 box">
    <div class="dmain flex"><img onclick="topxiala()" src="<?=weburl?>m/homeimg/top/close.png"></div>
    </div>
    
</div>

<script>

$(function(){
 //��������
	$("#asideclick").click(function(){

    	$("#asidebg").fadeIn(500)
        $("#bodywrap").addClass("bodywrap_left")
        $("#bodywrap header,#bodywrap footer,.filtermain,.topmenu").attr("style","margin-left:-17.5em;transition:0.5s;-moz-transition:0.5s;-webkit-transition:0.5s;-o-transition:0.5s;")
        $(".asidemenu").attr("style","right:0px; transition:0.5s;-moz-transition:0.5s;-webkit-transition:0.5s;-o-transition:0.5s; box-shadow:0 0 2.5em rgba(0,0,0,0.24);")
        
	});
	$("#asidebg").click(function(){
        $("#asidebg").fadeOut(500)
        $("body").attr("onmousewheel","return true;")
        $("#bodywrap").removeClass("bodywrap_left")
        $("#bodywrap").addClass("bodywrap_right")
        $("#bodywrap header,#bodywrap footer,.filtermain,.topmenu").attr("style","margin-left:0px;transition:0.5s;-moz-transition:0.5s;-webkit-transition:0.5s;-o-transition:0.5s;")
        $(".asidemenu").attr("style","right:-17.5em; transition:0.5s;-moz-transition:0.5s;-webkit-transition:0.5s;-o-transition:0.5s; ")
        setTimeout(function(){
            $("#bodywrap").removeClass("bodywrap_right")
        },500);
	});

});
</script>


