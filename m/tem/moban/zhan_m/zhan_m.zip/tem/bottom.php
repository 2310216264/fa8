<div class="bottommain"></div>
<div class="gbottom box">
<div class="d1">
 <div class="dm" onclick="gourl('<?=weburl?>m/')" id="bottom1"><img src="<?=weburl?>m/homeimg/zhan_mImg/bottom1.png" id="bottom1img" /><br>首页</div>
 <div class="dm" onclick="gourl('<?=weburl?>m/search/main.php')" id="bottom5"><img src="<?=weburl?>m/homeimg/zhan_mImg/bottom5.png" id="bottom5img" /><br>搜索</div>
 <div class="dm" onclick="gourl('<?=weburl?>m/user/order.php')" id="bottom2"><img src="<?=weburl?>m/homeimg/zhan_mImg/bottom2.png" id="bottom2img" /><br>订单</div>
 <div class="dm" onclick="gourl('<?=weburl?>m/user/car.php')" id="bottom3"><img src="<?=weburl?>m/homeimg/zhan_mImg/bottom3.png" id="bottom3img" /><br>购物车</div>
 <div class="dm" onclick="gourl('<?=weburl?>m/user/')" id="bottom4"><img src="<?=weburl?>m/homeimg/zhan_mImg/bottom4.png" id="bottom4img" /><br>我的</div>
</div>
</div>
<div style="display:none;"><?=$rowcontrol[webtj]?></div>